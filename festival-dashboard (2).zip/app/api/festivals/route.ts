import { NextResponse } from "next/server"

// Function to determine festival type based on genre
const determineFestivalType = (genre: string) => {
  const lowerGenre = genre.toLowerCase()

  if (
    lowerGenre.includes("metal") ||
    lowerGenre.includes("rock") ||
    lowerGenre.includes("punk") ||
    lowerGenre.includes("hardcore") ||
    lowerGenre.includes("thrash")
  ) {
    return "Rock/Metal"
  } else if (
    lowerGenre.includes("electro") ||
    lowerGenre.includes("techno") ||
    lowerGenre.includes("house") ||
    lowerGenre.includes("trance") ||
    lowerGenre.includes("edm") ||
    lowerGenre.includes("dance")
  ) {
    return "Electronic"
  } else if (lowerGenre.includes("hip-hop") || lowerGenre.includes("rap")) {
    return "Hip-Hop"
  } else if (lowerGenre.includes("pop")) {
    return "Pop"
  } else if (lowerGenre.includes("jazz") || lowerGenre.includes("blues")) {
    return "Jazz/Blues"
  } else if (
    lowerGenre.includes("folk") ||
    lowerGenre.includes("country") ||
    lowerGenre.includes("mittelalter") ||
    lowerGenre.includes("weltmusik") ||
    lowerGenre.includes("genreübergreifend")
  ) {
    return "Folk/World"
  } else if (lowerGenre.includes("klassik") || lowerGenre.includes("classic")) {
    return "Classical"
  } else if (lowerGenre.includes("reggae") || lowerGenre.includes("ska")) {
    return "Reggae/Ska"
  } else if (lowerGenre.includes("schlager")) {
    return "Schlager"
  }

  return "Verschiedene"
}

// Function to determine region based on postal code
const determineRegion = (plz: string) => {
  if (!plz) return "Unknown"

  // Remove any non-numeric characters and take the first digit
  const cleaned = plz.toString().replace(/[^0-9]/g, "")
  if (!cleaned) return "Unknown"

  // Special case for Berlin (various postcodes)
  if (
    plz.toString().includes("Berlin") ||
    cleaned.startsWith("10") ||
    cleaned.startsWith("12") ||
    cleaned.startsWith("13") ||
    cleaned.startsWith("14")
  ) {
    return "Ost"
  }

  const firstDigit = cleaned.charAt(0)

  if (firstDigit === "0" || firstDigit === "1") {
    return "Ost"
  } else if (firstDigit === "2") {
    return "Nord"
  } else if (firstDigit === "3" || firstDigit === "4" || firstDigit === "5") {
    return "West"
  } else if (firstDigit === "6" || firstDigit === "7" || firstDigit === "8" || firstDigit === "9") {
    return "Süd"
  }

  return "Unknown"
}

// Function to extract month from date string
const extractMonth = (dateStr: string) => {
  if (
    !dateStr ||
    dateStr === "k.A." ||
    dateStr === "T.B.A" ||
    dateStr === "Noch nicht bekannt" ||
    dateStr.includes("Noch nicht bekannt") ||
    dateStr.includes("T.B.A") ||
    dateStr.includes("abgesagt") ||
    dateStr.includes("Abgesagt")
  ) {
    return 0
  }

  // Handle date ranges (take the first date)
  if (dateStr.includes("–") || dateStr.includes("-")) {
    dateStr = dateStr.split(/[–-]/)[0].trim()
  }

  // Try to find a pattern like DD.MM.YYYY
  let match = dateStr.match(/\d{1,2}\.(\d{1,2})\.\d{4}/)
  if (match && match[1]) {
    return Number.parseInt(match[1])
  }

  // Try to handle other date formats (e.g., DD.MM or just MM)
  match = dateStr.match(/\d{1,2}\.(\d{1,2})/)
  if (match && match[1]) {
    return Number.parseInt(match[1])
  }

  // Handle dates with month names
  const monthNames: Record<string, number> = {
    januar: 1,
    februar: 2,
    märz: 3,
    april: 4,
    mai: 5,
    juni: 6,
    juli: 7,
    august: 8,
    september: 9,
    oktober: 10,
    november: 11,
    dezember: 12,
  }

  const lowerDateStr = dateStr.toLowerCase()
  for (const [name, num] of Object.entries(monthNames)) {
    if (lowerDateStr.includes(name)) {
      return num
    }
  }

  return 0
}

// Function to parse number from string
const parseNumber = (str: string) => {
  if (
    !str ||
    str === "k.A." ||
    str === "N.A" ||
    str === "N/A" ||
    str === "n/a" ||
    str === "ca." ||
    str.includes("k.A.") ||
    str.includes("N.A") ||
    str.includes("k/A") ||
    str.includes("K.A")
  ) {
    return 0
  }

  // Handle ranges by taking the average
  if (str.includes("–") || str.includes("-")) {
    const range = str.split(/[–-]/).map((s) => s.trim())
    if (range.length === 2) {
      const start = parseNumber(range[0])
      const end = parseNumber(range[1])
      return Math.round((start + end) / 2)
    }
  }

  // Handle "ca." prefix
  if (typeof str === "string" && str.includes("ca.")) {
    str = str.replace("ca.", "").trim()
  }

  // Handle strings with "pro Tag" or similar suffixes
  if (typeof str === "string" && (str.includes("pro Tag") || str.includes("pro Jahr") || str.includes("gesamt"))) {
    str = str.split("pro")[0].trim()
  }

  const cleaned = String(str)
    .replace(/[^0-9,.]/g, "")
    .replace(/\./g, "")
    .replace(/,/g, "")
  const num = Number.parseInt(cleaned)
  return isNaN(num) ? 0 : num
}

// Generate a descriptive text for the festival
const generateDescription = (item: any) => {
  let description = `${item.Name || "Das Festival"} findet`

  if (item.Datum && item.Datum !== "k.A." && !item.Datum.includes("abgesagt")) {
    description += ` vom ${item.Datum}`
  } else {
    description += ` in 2025`
  }

  if (item.Ort && item.Ort !== "k.A.") {
    description += ` in ${item.Ort}`
    if (item.PLZ && item.PLZ !== "k.A.") {
      description += ` (${item.PLZ})`
    }
  }

  description += " statt"

  if (item.Genre && item.Genre !== "k.A.") {
    description += ` und bietet ${item.Genre} Musik`
  }

  if (item.Besucher && item.Besucher !== "k.A.") {
    const visitors = parseNumber(item.Besucher)
    if (visitors > 0) {
      if (visitors < 1000) {
        description += `. Es ist ein kleines Festival mit rund ${visitors} Besuchern`
      } else if (visitors < 10000) {
        description += `. Es ist ein mittelgroßes Festival mit rund ${visitors.toLocaleString()} Besuchern`
      } else if (visitors < 50000) {
        description += `. Es ist ein großes Festival mit rund ${visitors.toLocaleString()} Besuchern`
      } else {
        description += `. Es ist ein sehr großes Festival mit rund ${visitors.toLocaleString()} Besuchern`
      }
    }
  }

  description += "."
  return description
}

// Funktion zum Cachen von Geocoding-Ergebnissen
const geocodeCache = new Map()

// Funktion zum Geocodieren einer Adresse
const geocodeAddress = async (address) => {
  // Prüfen, ob die Adresse bereits im Cache ist
  if (geocodeCache.has(address)) {
    return geocodeCache.get(address)
  }

  try {
    // Füge einen User-Agent Header hinzu und respektiere die Rate-Limits
    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}&limit=1`,
      {
        headers: {
          "User-Agent": "BehnFestivalDashboard/1.0",
        },
      },
    )

    // Prüfe auf Rate-Limit-Fehler
    if (response.status === 429) {
      console.log("Rate limit erreicht, überspringe Geocoding für:", address)
      return null
    }

    const data = await response.json()

    if (data && data.length > 0) {
      const result = {
        lat: Number.parseFloat(data[0].lat),
        lon: Number.parseFloat(data[0].lon),
      }

      // Ergebnis im Cache speichern
      geocodeCache.set(address, result)

      return result
    }

    // Leeres Ergebnis im Cache speichern, um wiederholte Anfragen zu vermeiden
    geocodeCache.set(address, null)
    return null
  } catch (error) {
    console.error("Fehler beim Geocodieren:", error)
    return null
  }
}

// Parse CSV data
const parseCSV = (csvText: string) => {
  const lines = csvText.split("\n")
  const headers = lines[0].split(",").map((header) => header.trim())

  const result = []

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim()
    if (!line) continue

    // Handle commas within quoted fields
    const values = []
    let inQuotes = false
    let currentValue = ""

    for (let j = 0; j < line.length; j++) {
      const char = line[j]

      if (char === '"') {
        inQuotes = !inQuotes
      } else if (char === "," && !inQuotes) {
        values.push(currentValue)
        currentValue = ""
      } else {
        currentValue += char
      }
    }

    values.push(currentValue) // Add the last value

    // Create object from headers and values
    const obj: Record<string, string> = {}
    for (let j = 0; j < headers.length; j++) {
      obj[headers[j]] = j < values.length ? values[j].replace(/^"|"$/g, "") : ""
    }

    result.push(obj)
  }

  return result
}

export async function GET() {
  try {
    // Fetch the CSV file from the provided URL
    const csvUrl =
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Unbenannte%20Tabelle%20-%20Tabellenblatt1-jRVLuFgapHaOy9sOsKVsd8WCMoU8Ha.csv"
    const response = await fetch(csvUrl)

    if (!response.ok) {
      throw new Error(`Failed to fetch CSV: ${response.status} ${response.statusText}`)
    }

    const csvText = await response.text()
    const parsedCsv = parseCSV(csvText)

    // Process the parsed CSV data without geocoding all addresses at once
    const festivals = parsedCsv.map((item, index) => {
      // Extract estimated duration from date if available
      let calculatedDuration = 1
      if (item.Datum && (item.Datum.includes("–") || item.Datum.includes("-"))) {
        const dates = item.Datum.split(/[–-]/).map((d) => d.trim())
        if (dates.length === 2) {
          // Try to extract dates
          const startMatch = dates[0].match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/)
          const endMatch = dates[1].match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/)

          if (startMatch && endMatch) {
            const startDay = Number.parseInt(startMatch[1])
            const startMonth = Number.parseInt(startMatch[2])
            const startYear = Number.parseInt(startMatch[3])

            const endDay = Number.parseInt(endMatch[1])
            const endMonth = Number.parseInt(endMatch[2])
            const endYear = Number.parseInt(endMatch[3])

            if (
              !isNaN(startDay) &&
              !isNaN(endDay) &&
              !isNaN(startMonth) &&
              !isNaN(endMonth) &&
              !isNaN(startYear) &&
              !isNaN(endYear)
            ) {
              const startDate = new Date(startYear, startMonth - 1, startDay)
              const endDate = new Date(endYear, endMonth - 1, endDay)
              const diffTime = Math.abs(endDate.getTime() - startDate.getTime())
              const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1 // +1 to include both start and end days

              calculatedDuration = diffDays
            }
          }
        }
      }

      // Determine festival type
      const festivalType = determineFestivalType(item.Genre || "")
      const region = determineRegion(item.PLZ || item.Ort || "")

      // Process into our required format without geocoding
      return {
        id: index + 1,
        name: item.Name || `Festival ${index + 1}`,
        location: item.Ort || "Unknown",
        plz: item.PLZ || "",
        date: item.Datum || "",
        month: extractMonth(item.Datum),
        duration: parseNumber(item.Dauer) || calculatedDuration,
        genre: item.Genre || "Unknown",
        visitors: parseNumber(item.Besucher),
        instaFollowers: parseNumber(item["Instagram Follower April 25"]),
        region: region,
        website: `www.${item.Name?.toLowerCase().replace(/[^a-z0-9]/g, "-")}.de`,
        contact: `info@${item.Name?.toLowerCase().replace(/[^a-z0-9]/g, "-")}.de`,
        festivalType: festivalType,
        description: generateDescription(item),
      }
    })

    return NextResponse.json({ festivals })
  } catch (error) {
    console.error("Error processing festival data:", error)
    return NextResponse.json(
      { error: "Failed to process festival data", details: (error as Error).message },
      { status: 500 },
    )
  }
}
