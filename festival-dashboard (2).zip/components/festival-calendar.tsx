"use client"

import type React from "react"

import { useState, useEffect, useMemo } from "react"
import { ChevronLeft, ChevronRight, CalendarIcon, Info, X } from "lucide-react"
import { useTheme } from "@/contexts/theme-context"

// Typen für die Festivals und Props
interface Festival {
  id: number
  name: string
  location: string
  plz: string
  date: string
  month: number
  duration: number
  genre: string
  visitors: number
  instaFollowers: number
  region: string
  website: string
  contact: string
  festivalType: string
  description: string
}

interface FestivalCalendarProps {
  festivals: Festival[]
  onSelectFestival: (festival: Festival) => void
  currentMonth: number
  onMonthChange: (month: number) => void
}

// Hilfsfunktion zum Extrahieren des Tages aus einem Datumsstring
const extractDayFromDate = (dateStr: string): number | null => {
  if (!dateStr || dateStr === "k.A." || dateStr.includes("T.B.A") || dateStr.includes("abgesagt")) {
    return null
  }

  // Wenn es ein Datumsbereich ist, nehmen wir den ersten Tag
  if (dateStr.includes("–") || dateStr.includes("-")) {
    dateStr = dateStr.split(/[–-]/)[0].trim()
  }

  // Versuche, ein Muster wie DD.MM.YYYY zu finden
  let match = dateStr.match(/(\d{1,2})\.\d{1,2}\.\d{4}/)
  if (match && match[1]) {
    return Number.parseInt(match[1], 10)
  }

  // Versuche, ein Muster wie DD.MM zu finden
  match = dateStr.match(/(\d{1,2})\.\d{1,2}/)
  if (match && match[1]) {
    return Number.parseInt(match[1], 10)
  }

  return null
}

const FestivalCalendar: React.FC<FestivalCalendarProps> = ({
  festivals,
  onSelectFestival,
  currentMonth,
  onMonthChange,
}) => {
  const { theme } = useTheme()
  const [year, setYear] = useState(new Date().getFullYear())
  const [month, setMonth] = useState(currentMonth)
  const [hoveredDay, setHoveredDay] = useState<number | null>(null)
  const [selectedDay, setSelectedDay] = useState<number | null>(null)
  const [showDayModal, setShowDayModal] = useState(false)

  // Synchronisiere den lokalen Monat mit dem übergebenen currentMonth
  useEffect(() => {
    setMonth(currentMonth)
  }, [currentMonth])

  // Berechne die Tage im aktuellen Monat
  const daysInMonth = useMemo(() => {
    return new Date(year, month, 0).getDate()
  }, [year, month])

  // Berechne den Wochentag des ersten Tags im Monat (0 = Sonntag, 1 = Montag, ...)
  const firstDayOfMonth = useMemo(() => {
    return new Date(year, month - 1, 1).getDay()
  }, [year, month])

  // Gruppiere Festivals nach Tag
  const festivalsByDay = useMemo(() => {
    const result: { [key: number]: Festival[] } = {}

    // Initialisiere alle Tage des Monats mit leeren Arrays
    for (let i = 1; i <= daysInMonth; i++) {
      result[i] = []
    }

    // Filtere Festivals für den aktuellen Monat und gruppiere sie nach Tag
    festivals
      .filter((festival) => festival.month === month)
      .forEach((festival) => {
        const day = extractDayFromDate(festival.date)
        if (day !== null && day >= 1 && day <= daysInMonth) {
          result[day].push(festival)
        }
      })

    return result
  }, [festivals, month, daysInMonth])

  // Berechne die maximale Anzahl von Festivals an einem Tag für die Farbintensität
  const maxFestivalsPerDay = useMemo(() => {
    return Math.max(1, ...Object.values(festivalsByDay).map((festivals) => festivals.length))
  }, [festivalsByDay])

  // Navigiere zum vorherigen Monat
  const prevMonth = () => {
    if (month === 1) {
      setYear(year - 1)
      setMonth(12)
      onMonthChange(12)
    } else {
      setMonth(month - 1)
      onMonthChange(month - 1)
    }
  }

  // Navigiere zum nächsten Monat
  const nextMonth = () => {
    if (month === 12) {
      setYear(year + 1)
      setMonth(1)
      onMonthChange(1)
    } else {
      setMonth(month + 1)
      onMonthChange(month + 1)
    }
  }

  // Navigiere zum aktuellen Monat
  const goToCurrentMonth = () => {
    const today = new Date()
    setYear(today.getFullYear())
    setMonth(today.getMonth() + 1)
    onMonthChange(today.getMonth() + 1)
  }

  // Berechne die Hintergrundfarbe basierend auf der Anzahl der Festivals
  const getBackgroundColor = (day: number) => {
    const count = festivalsByDay[day]?.length || 0
    if (count === 0) return theme === "dark" ? "bg-gray-800" : "bg-white"

    const intensity = Math.min(900, Math.floor((count / maxFestivalsPerDay) * 900))
    // Wir verwenden eine Skala von 50 bis 900 für die Farbintensität
    const colorIntensity = Math.max(50, Math.min(900, 50 + intensity))

    return theme === "dark" ? `bg-red-${colorIntensity}/20` : `bg-red-${colorIntensity}/20`
  }

  // Berechne die Textfarbe basierend auf der Hintergrundfarbe
  const getTextColor = (day: number) => {
    const count = festivalsByDay[day]?.length || 0
    if (count === 0) return theme === "dark" ? "text-gray-400" : "text-gray-500"

    const intensity = Math.min(900, Math.floor((count / maxFestivalsPerDay) * 900))
    // Ab einer bestimmten Intensität wechseln wir zu weißem Text
    return theme === "dark"
      ? intensity > 300
        ? "text-red-300"
        : "text-gray-200"
      : intensity > 300
        ? "text-red-800"
        : "text-gray-900"
  }

  // Öffne das Modal für einen bestimmten Tag
  const openDayModal = (day: number) => {
    setSelectedDay(day)
    setShowDayModal(true)
  }

  // Schließe das Modal
  const closeDayModal = () => {
    setShowDayModal(false)
    setSelectedDay(null)
  }

  // Generiere die Wochentagsüberschriften
  const weekdays = ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"]

  // Generiere die Kalender-Grid-Zellen
  const renderCalendarCells = () => {
    const cells = []

    // Leere Zellen für die Tage vor dem ersten Tag des Monats
    for (let i = 0; i < firstDayOfMonth; i++) {
      cells.push(
        <div
          key={`empty-${i}`}
          className="h-24 border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50"
        ></div>,
      )
    }

    // Zellen für die Tage des Monats
    for (let day = 1; day <= daysInMonth; day++) {
      const festivalsForDay = festivalsByDay[day] || []
      const hasMoreFestivals = festivalsForDay.length > 3

      cells.push(
        <div
          key={day}
          className={`h-24 border border-gray-200 dark:border-gray-700 p-1 transition-colors relative ${getBackgroundColor(day)} hover:bg-red-100 dark:hover:bg-red-900/20 cursor-pointer`}
          onClick={() => openDayModal(day)}
          onMouseEnter={() => setHoveredDay(day)}
          onMouseLeave={() => setHoveredDay(null)}
        >
          <div className={`text-right font-semibold ${getTextColor(day)}`}>{day}</div>

          <div className="mt-1 overflow-hidden">
            {festivalsForDay.length > 0 ? (
              <>
                {/* Nur das erste Festival direkt anzeigen */}
                <div
                  key={festivalsForDay[0].id}
                  onClick={(e) => {
                    e.stopPropagation() // Verhindert, dass das Tag-Modal geöffnet wird
                    onSelectFestival(festivalsForDay[0])
                  }}
                  className="text-xs truncate mb-1 bg-white dark:bg-gray-800 bg-opacity-90 dark:bg-opacity-90 p-1 rounded cursor-pointer hover:bg-red-50 dark:hover:bg-red-900/20"
                >
                  {festivalsForDay[0].name}
                </div>

                {/* Wenn es mehr als ein Festival gibt, zeige den "+weitere" Button */}
                {festivalsForDay.length > 1 && (
                  <div
                    className="text-xs text-center bg-red-600 dark:bg-red-700 text-white p-1 rounded cursor-pointer hover:bg-red-500 dark:hover:bg-red-600"
                    onClick={(e) => {
                      e.stopPropagation()
                      openDayModal(day)
                    }}
                  >
                    +{festivalsForDay.length - 1} weitere
                  </div>
                )}
              </>
            ) : null}
          </div>

          {/* Tooltip für Hover */}
          {hoveredDay === day && festivalsForDay.length > 0 && (
            <div className="absolute z-10 left-full top-0 ml-2 bg-white dark:bg-gray-800 shadow-lg dark:shadow-gray-900/30 rounded-md border border-gray-200 dark:border-gray-700 p-2 w-64">
              <div className="font-semibold mb-1 text-gray-900 dark:text-gray-100">
                {day}. Tag - {festivalsForDay.length} Festivals
              </div>
              <div className="max-h-48 overflow-y-auto">
                {festivalsForDay.map((festival) => (
                  <div
                    key={festival.id}
                    onClick={(e) => {
                      e.stopPropagation() // Verhindert, dass das Tag-Modal geöffnet wird
                      onSelectFestival(festival)
                    }}
                    className="text-sm p-1 hover:bg-red-50 dark:hover:bg-red-900/20 cursor-pointer rounded mb-1 text-gray-700 dark:text-gray-300"
                  >
                    {festival.name} - {festival.location}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>,
      )
    }

    return cells
  }

  // Berechne die Gesamtzahl der Festivals im aktuellen Monat
  const totalFestivalsInMonth = useMemo(() => {
    return Object.values(festivalsByDay).reduce((sum, festivals) => sum + festivals.length, 0)
  }, [festivalsByDay])

  const monthName = new Date(year, month - 1).toLocaleString("de-DE", { month: "long" })

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md transition-colors duration-300">
      {/* Kalender-Header */}
      <div className="flex items-center justify-between p-4 bg-red-700 dark:bg-red-900 text-white rounded-t-lg transition-colors duration-300">
        <div className="flex items-center">
          <button
            onClick={prevMonth}
            className="p-2 rounded-full hover:bg-red-600 dark:hover:bg-red-800 transition-colors"
            aria-label="Vorheriger Monat"
          >
            <ChevronLeft size={20} />
          </button>
          <h2 className="text-xl font-bold flex items-center mx-2">
            <CalendarIcon className="mr-2" size={20} />
            {monthName} {year}
          </h2>
          <button
            onClick={nextMonth}
            className="p-2 rounded-full hover:bg-red-600 dark:hover:bg-red-800 transition-colors"
            aria-label="Nächster Monat"
          >
            <ChevronRight size={20} />
          </button>
        </div>
        <div className="flex items-center space-x-2">
          <div className="text-sm bg-red-800 dark:bg-red-950 px-3 py-1 rounded">{totalFestivalsInMonth} Festivals</div>
          <button
            onClick={goToCurrentMonth}
            className="text-sm bg-red-600 dark:bg-red-800 hover:bg-red-500 dark:hover:bg-red-700 px-3 py-1 rounded transition-colors"
          >
            Aktueller Monat
          </button>
        </div>
      </div>

      {/* Kalender-Legende */}
      <div className="bg-red-50 dark:bg-red-900/20 p-3 flex items-center text-sm border-b border-red-100 dark:border-red-900/30 transition-colors duration-300">
        <Info size={16} className="text-red-700 dark:text-red-400 mr-2" />
        <span className="text-gray-700 dark:text-gray-300">
          Die Intensität der Farbe zeigt die Anzahl der Festivals pro Tag. Klicken Sie auf einen Tag, um alle Festivals
          anzuzeigen.
        </span>
      </div>

      {/* Wochentagsüberschriften */}
      <div className="grid grid-cols-7 bg-gray-100 dark:bg-gray-800 transition-colors duration-300">
        {weekdays.map((day) => (
          <div key={day} className="py-2 text-center font-medium text-gray-700 dark:text-gray-300">
            {day}
          </div>
        ))}
      </div>

      {/* Kalender-Grid */}
      <div className="grid grid-cols-7">{renderCalendarCells()}</div>

      {/* Kalender-Footer */}
      <div className="p-3 bg-gray-50 dark:bg-gray-700 text-xs text-gray-500 dark:text-gray-400 rounded-b-lg border-t border-gray-200 dark:border-gray-600 transition-colors duration-300">
        Hinweis: Festivals ohne genaues Datum oder mit unvollständigen Datumsangaben werden möglicherweise nicht
        angezeigt.
      </div>

      {/* Modal für Tagesansicht */}
      {showDayModal && selectedDay !== null && (
        <div
          className="fixed inset-0 overflow-y-auto z-50"
          aria-labelledby="day-modal-title"
          role="dialog"
          aria-modal="true"
        >
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div
              className="fixed inset-0 bg-gray-500 bg-opacity-75 dark:bg-gray-900 dark:bg-opacity-75 transition-opacity"
              aria-hidden="true"
              onClick={closeDayModal}
            ></div>

            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">
              &#8203;
            </span>

            <div className="inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="absolute top-0 right-0 pt-4 pr-4">
                <button
                  type="button"
                  className="bg-white dark:bg-gray-800 rounded-md text-gray-400 dark:text-gray-500 hover:text-gray-500 dark:hover:text-gray-400 focus:outline-none"
                  onClick={closeDayModal}
                  aria-label="Schließen"
                >
                  <span className="sr-only">Schließen</span>
                  <X size={20} />
                </button>
              </div>

              <div className="bg-white dark:bg-gray-800 px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 dark:bg-red-900/20 sm:mx-0 sm:h-10 sm:w-10">
                    <CalendarIcon className="h-6 w-6 text-red-600 dark:text-red-400" />
                  </div>
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                    <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-gray-100" id="day-modal-title">
                      {selectedDay}. {monthName} {year}
                    </h3>
                    <div className="mt-4">
                      {festivalsByDay[selectedDay]?.length > 0 ? (
                        <div className="space-y-2">
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {festivalsByDay[selectedDay].length} Festivals an diesem Tag:
                          </p>
                          <div className="max-h-96 overflow-y-auto">
                            <div className="bg-gray-50 dark:bg-gray-700 rounded-md divide-y divide-gray-200 dark:divide-gray-600">
                              {festivalsByDay[selectedDay].map((festival) => (
                                <div
                                  key={festival.id}
                                  className="p-3 hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer transition-colors"
                                  onClick={() => {
                                    closeDayModal()
                                    onSelectFestival(festival)
                                  }}
                                >
                                  <div className="flex justify-between items-start">
                                    <div>
                                      <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100">
                                        {festival.name}
                                      </h4>
                                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                                        {festival.location} {festival.plz && `(${festival.plz})`}
                                      </p>
                                    </div>
                                    <div>
                                      <span
                                        className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        ${
                                          festival.festivalType === "Rock/Metal"
                                            ? "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
                                            : festival.festivalType === "Electronic"
                                              ? "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300"
                                              : festival.festivalType === "Hip-Hop"
                                                ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"
                                                : festival.festivalType === "Pop"
                                                  ? "bg-pink-100 text-pink-800 dark:bg-pink-900/20 dark:text-pink-300"
                                                  : festival.festivalType === "Jazz/Blues"
                                                    ? "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
                                                    : festival.festivalType === "Folk/World"
                                                      ? "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
                                                      : festival.festivalType === "Classical"
                                                        ? "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300"
                                                        : festival.festivalType === "Reggae/Ska"
                                                          ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/20 dark:text-emerald-300"
                                                          : festival.festivalType === "Schlager"
                                                            ? "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300"
                                                            : "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300"
                                        }`}
                                      >
                                        {festival.festivalType}
                                      </span>
                                    </div>
                                  </div>
                                  <div className="mt-2 flex justify-between text-xs">
                                    <span className="text-gray-500 dark:text-gray-400">
                                      {festival.visitors ? `${festival.visitors.toLocaleString()} Besucher` : ""}
                                    </span>
                                    <span className="text-gray-500 dark:text-gray-400">
                                      {festival.duration} {festival.duration === 1 ? "Tag" : "Tage"}
                                    </span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      ) : (
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Keine Festivals an diesem Tag gefunden.
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 dark:bg-red-700 text-base font-medium text-white hover:bg-red-700 dark:hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 dark:focus:ring-red-400 sm:ml-3 sm:w-auto sm:text-sm"
                  onClick={closeDayModal}
                >
                  Schließen
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default FestivalCalendar
